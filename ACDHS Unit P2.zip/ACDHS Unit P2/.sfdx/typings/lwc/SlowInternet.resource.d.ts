declare module "@salesforce/resourceUrl/SlowInternet" {
    var SlowInternet: string;
    export default SlowInternet;
}