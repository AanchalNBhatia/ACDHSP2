import { LightningElement,track,api,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {getObjectInfo} from 'lightning/uiObjectInfoApi';
import ExternalReferral_Obj from '@salesforce/schema/External_Referral__c';
export default class RecordExternalReferral extends LightningElement {

    @api isModalOpen=false;
    @api clientId;
    @api interactionId;
    @api clientName;
    @api objRecordId;
    @api recRtName;
    exrefFields=[];
    allRTInfo={};
    @track selectedRTId = '';

    @wire(getObjectInfo,{objectApiName:ExternalReferral_Obj})
    wiredObjectData(result){
        if(result.data){
            this.allRTInfo = result.data.recordTypeInfos;
            Object.entries(this.allRTInfo).forEach(item=>{
                if(item[1].name == this.recRtName){
                    console.log(item[1].name);
                    this.selectedRTId = item[1].recordTypeId;
                    console.log('In Record '+this.selectedRTId);
                }
            })
        }
    }


    openModal()
    {
        this.isModalOpen=true;
    }
    closeModal()
    {
        this.isModalOpen=false;
        const closeevent2= new CustomEvent('closeevent2', {
            detail:{} 
        });
        this.dispatchEvent(closeevent2);
        //console.log(closeEvent)
    }
    handleClear()
    {
        this.template.querySelectorAll('lightning-input-field').forEach(each => {
            each.value = null;
        });
    }
    handleSave(event)
    {
        event.preventDefault(); 
        const fields = event.detail.fields;
        fields.Client__c=this.clientId;
        fields.Interaction__c=this.interactionId;
        if(this.recRtName==='Referral')
        {
            fields.Referral__c = this.objRecordId;
        }else{
            fields.Client_Service__c = this.objRecordId
        }
        fields.RecordTypeId=this.selectedRTId;
        this.exrefFields=fields;
        console.log(JSON.parse(JSON.stringify(this.exrefFields)));
        this.template.querySelector('lightning-record-edit-form').submit(fields);
        
    }
    handleSuccess(event)
    {
        this.exrefId=event.detail.id;
        const toastEvent = new ShowToastEvent({
            title: 'Success !!',
            message: 'External Referral saved for Client '+this.clientName,
            variant:'success'
        });
        this.dispatchEvent(toastEvent);
        this.isModalOpen = false;
        const closeEvent= new CustomEvent('closeevent', {
            detail:{exData:this.exrefFields, eventexrefId:this.exrefId} 
        });
        this.dispatchEvent(closeEvent);
    }
    handleError(event){
        console.log('Inside handle error');
        console.log(event);
        console.log(JSON.parse(JSON.stringify(event.detail)));
    }
}