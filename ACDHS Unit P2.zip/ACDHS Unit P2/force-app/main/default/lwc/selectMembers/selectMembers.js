import { LightningElement, track, wire, api } from 'lwc';
import getMembers from '@salesforce/apex/AssignServiceController.getMembers';
import { refreshApex } from '@salesforce/apex';

const columns = [
    { 
        label: 'Name', 
        fieldName: 'clientURL',
        type: 'url',
        typeAttributes: {label: { fieldName: 'clientName' }, 
        target: '_blank'},
        sortable: true
    },
    { label: 'MCI ID', fieldName: 'clientMCIId'},
    { label: 'Relationship', fieldName: 'relationship'},
    { label: 'DOB', 
        fieldName: 'clientDOB',
        type: 'date',
        typeAttributes: {
            day: "numeric",
            month: "numeric",
            year: "numeric"
        }
    },
    {
        type: "button",
        fixedWidth: 150,
        label:"Select",
        typeAttributes: {
            label:{fieldName: 'selectToggle'},
            title: 'Select',
            name: 'select',
            value: 'select',
            variant: {fieldName: 'selectButtonVariant'},
            disabled: {fieldName: 'isSelectDisabled'}
        }
    },
    {
        type: "button",
        fixedWidth: 150,
        label:"Get MCI ID",
        typeAttributes: {
            label: "Get MCI ID",
            title: 'getMciId',
            name: 'getMciId',
            value: 'getMciId',
            variant: 'brand',
            disabled: {fieldName: 'isGetMCIDisabled'}
        }
    },
];

export default class SelectMembers extends LightningElement {
    @api existingSelection;
    @api referralId;
    @track membersList;
    wiredMembersList;
    error;
    columns = columns
    isMCI = false;
    clientIdInQues;

    connectedCallback(){
    }

    @wire(getMembers, {referralId : '$referralId'})
    wiredMembers(result){
        this.wiredMembersList = result;
        if(result.data){
            this.membersList = JSON.parse(JSON.stringify(result.data));
            this.error = undefined;
            if(this.existingSelection && this.existingSelection.length){
                this.membersList.forEach(member => {
                    this.existingSelection.forEach(selMember => {
                        if(member.clientId === selMember.clientId){
                            member.selectToggle = 'Selected';
                            member.selectButtonVariant = 'success';
                        }
                    })
                })
            }
            //console.log('Members # '+JSON.stringify(this.membersList));
        }else if(result.error){
            this.membersList = undefined;
            this.error = result.error;
        }
    }

    handleRowAction(event){
        let actionName = event.detail.action.name;
        let selectedClientId = event.detail.row.clientId;
        //console.log("Button name # "+event.detail.action.name);
        //console.log("Row data # "+JSON.stringify(event.detail.row.clientId));
        if(actionName === 'select'){
            let selPos = this.membersList.findIndex(j=>j.clientId===selectedClientId);
            if(this.membersList[selPos].selectToggle === 'Select'){
                this.membersList[selPos].selectToggle = 'Selected';
                this.membersList[selPos].selectButtonVariant = 'success';
            }else{
                this.membersList[selPos].selectToggle = 'Select';
                this.membersList[selPos].selectButtonVariant = 'neutral';
            }
            //console.log("Updated # "+JSON.stringify(this.membersList));
            this.membersList = JSON.parse(JSON.stringify(this.membersList));

            let filteredMembers = [];

            this.membersList.forEach(member => {
                if(member.selectToggle === 'Selected'){
                    filteredMembers.push(member);
                }
            });

            if(this.membersList.findIndex(j=>j.clientId===selectedClientId) !== -1){
                const membersEvent = new CustomEvent('membersselected', {detail : filteredMembers});
                this.dispatchEvent(membersEvent);
            }else{
                const membersEvent = new CustomEvent('membersselected', {detail : []});
                this.dispatchEvent(membersEvent);
            }
        }else if(actionName === 'getMciId'){
            this.clientIdInQues = selectedClientId;
            this.isMCI = true;
        }
    }

    closeModal(event){
        this.isMCI = false;
    }

    handleMCIClose(event){
        refreshApex(this.wiredMembersList);
        this.membersList = JSON.parse(JSON.stringify(this.membersList));
        this.isMCI = false;
    }
}