import { LightningElement, api, wire, track } from 'lwc';
import { getRecord, getFieldValue, updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import searchClient from '@salesforce/apex/MciCalloutHelper.searchClient';
import insertNewClient from '@salesforce/apex/MciCalloutHelper.insertNewClient';
import updateClient from '@salesforce/apex/MciCalloutHelper.updateClient';
import mci_Field from '@salesforce/schema/Client__c.MCI_ID__c';
import id_Field from '@salesforce/schema/Client__c.Id';
import createMCI_Field from '@salesforce/schema/Client__c.Client_Create_MCI__c';
import newClientMinScore from '@salesforce/label/c.MCI_New_Client_Min_Score';

const clientFields = ['Client__c.Name', 'Client__c.First_Name__c', 'Client__c.Last_Name__c', 'Client__c.Date_of_Birth__c', 'Client__c.Legal_Sex__c', 'Client__c.SSN__c'];

export default class Mci_clearance extends LightningElement {
    isLoading = false;
    error;
    @api recordId;
    clientIdVal; fNameVal; lNameVal; dobVal; legalSexVal; ssnVal;
    @track columns = [
        { label: 'MCI ID', fieldName: 'mciId' },
        { label: 'First Name', fieldName: 'firstName', type: 'text' },
        { label: 'Middle Name', fieldName: 'middleName', type: 'text' },
        { label: 'Last Name', fieldName: 'lastName', type: 'text' },
        { label: 'Legal Sex', fieldName: 'genderText', type: 'text' },
        { label: 'DOB', fieldName: 'birthDate', type: 'date' },
        { label: 'SSN', fieldName: 'ssn', type: 'text' },
        { label: 'Score', fieldName: 'score', type: 'text' }
    ];
    @track clientData = [];
    disableUpdateButton = true;
    maxScore = 0;
    clientExist = true; errorMessage;
    noRecord = false; noAccess = false;


    @wire(getRecord, { recordId: '$recordId', fields: clientFields })
    wiredClientData (result) {
        if (result.data)
        {
            const fields = {};
            fields[id_Field.fieldApiName] = this.recordId;
            fields[createMCI_Field.fieldApiName] = true;
            const recordInput = { fields };
            updateRecord(recordInput)
            .then(() => {})
            .catch(error => {
                console.log('#### create mci error: ' + JSON.stringify(error));
                console.log('#### error: ' + error.body.output.errors[0].message);
                if (error.body.output.errors[0].message == 'insufficient access rights on object id')
                {
                    this.noAccess = true;
                    this.noRecord = true;
                }
            });

            this.clientIdVal = getFieldValue(result.data, 'Client__c.Name');
            this.fNameVal = getFieldValue(result.data, 'Client__c.First_Name__c');
            this.lNameVal = getFieldValue(result.data, 'Client__c.Last_Name__c');
            this.dobVal = getFieldValue(result.data, 'Client__c.Date_of_Birth__c');
            this.legalSexVal = getFieldValue(result.data, 'Client__c.Legal_Sex__c');
            this.ssnVal = getFieldValue(result.data, 'Client__c.SSN__c');

            if (this.fNameVal == null || this.lNameVal == null || this.dobVal == null || this.legalSexVal == null)
            {
                const event = new ShowToastEvent({
                    title: 'Error',
                    message: 'MCI clearance cannot be completed until Date of Birth is filled.',
                    variant: 'error'
                });
                this.dispatchEvent(event);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
            else
            {
                this.isLoading = true;
                this.startClearence();
            }
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### wiredClientData error: ' + JSON.stringify(result.error));
        }
    }

    startClearence () {
        var clientJSON;
        if (this.ssnVal == null || this.ssnVal == '' || this.ssnVal == undefined)
        {
            var clientJSON = {
                "firstName" : this.fNameVal,
                "lastName" : this.lNameVal,
                "genderCode" : this.legalSexVal,
                "birthDate" : this.dobVal
            };
        }
        else
        {
            var clientJSON = {
                "firstName" : this.fNameVal,
                "lastName" : this.lNameVal,
                "genderCode" : this.legalSexVal,
                "birthDate" : this.dobVal,
                "ssn" : this.ssnVal
            };
        }
        
        console.log('#### clientJSON: ' + JSON.stringify(clientJSON));

        searchClient({client: JSON.stringify(clientJSON)})
        .then((result) => {
            console.log('#### searchClient result: ' + result);
            var response = result.split('####');
            console.log('#### response: ' + JSON.stringify(response));
            if (response[0] == '200')
            {
                this.clientData = JSON.parse(response[1].replace(/T00:00:00/g, ''));
                console.log('#### this.clientData: ' + JSON.stringify(this.clientData));
                var maxS = 0;
                JSON.parse(response[1]).forEach(function(cd){
                    if (parseInt(cd.score) > maxS) maxS = parseInt(cd.score);
                });
                this.maxScore = maxS;
            }
            else if (response[0] == '204') //No Record exist in MCI
            {
                this.clientExist = false;
                this.noRecord = true;
                this.errorMessage = 'No MCI ID matches were found for this Client. Click \'Create New MCI ID\' to proceed.';
            }
            /* else if (response[0] == '500')
            {} */
            else
            {
                this.clientExist = false;
                this.noRecord = true;
                this.errorMessage = 'MCI is currently unavailable. Please contact the DHS Service Desk at (412) 350-4357 or ServiceDesk@AlleghenyCounty.US. The error code is: ' + response[0];
            }
            this.isLoading = false;
        })
        .catch((error) => {
            this.error = error;
            console.log('#### searchClient error: ' + JSON.stringify(error));
            this.isLoading = false;
        });
    }

    handleUpdateButton () {
        if (this.template.querySelector('lightning-datatable').getSelectedRows() == null || this.template.querySelector('lightning-datatable').getSelectedRows().length == 0)
        {
            const event = new ShowToastEvent({
                title: 'Error',
                message: 'Select a value from the table to update MCI ID into the record.',
                variant: 'error'
            });
            this.dispatchEvent(event);
        }
        else
        {
            console.log('#### selectedRows: ' + this.template.querySelector('lightning-datatable').getSelectedRows()[0].mciId);
            this.updateMciID(this.template.querySelector('lightning-datatable').getSelectedRows()[0].mciId.toString());
        }
    }

    updateMciID (mciId) {
        const fields = {};
        fields[id_Field.fieldApiName] = this.recordId;
        fields[mci_Field.fieldApiName] = mciId;

        const recordInput = { fields };

            updateRecord(recordInput)
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'MCI ID Updated',
                        variant: 'success'
                    })
                );
                this.updateDataBackToMCI(mciId);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            })
            .catch(error => {
                console.log('#### update mciId error: ' + JSON.stringify(error));
                console.log('#### error: ' + error.body.output.errors[0].message);
                var errMsg = 'Some error occured. Please try again or contact your System Admin';
                if (error.body.output.errors[0].message)
                {
                    if (error.body.output.errors[0].message.includes('insufficient access'))
                    {
                        errMsg = 'You do not have required permission to update this record.';
                    }
                }
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: errMsg,
                        variant: 'error'
                    })
                );
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            });
    }

    handleCancelButton () {
        const closeLwc = new CustomEvent('close');
        this.dispatchEvent(closeLwc);
    }

    handleCreateButton () {
        console.log('#### max score: ' + this.maxScore);
        var minScore = Number.isInteger(parseInt(newClientMinScore)) ? parseInt(newClientMinScore) : 0;
        console.log('#### minScore: ' + minScore);
        var msg = 'You cannot create a new record if an existing record matches ' + minScore + '% or above.';
        if (this.maxScore >= minScore)
        {
            const event = new ShowToastEvent({
                title: 'Error',
                message: msg,
                variant: 'error'
            });
            this.dispatchEvent(event);
        }
        else
        {
            this.createNewMCI();
        }
    }

    createNewMCI () {
        var clientJSON;
        if (this.ssnVal == null || this.ssnVal == '' || this.ssnVal == undefined)
        {
            var clientJSON = {
                "sourceSystemId" : "53",
                "sourceSystemClientId" : this.clientIdVal,
                "firstName" : this.fNameVal,
                "lastName" : this.lNameVal,
                "genderCode" : this.legalSexVal,
                "birthDate" : this.dobVal
            };
        }
        else
        {
            var clientJSON = {
                "sourceSystemId" : "53",
                "sourceSystemClientId" : this.clientIdVal,
                "firstName" : this.fNameVal,
                "lastName" : this.lNameVal,
                "genderCode" : this.legalSexVal,
                "birthDate" : this.dobVal,
                "ssn" : this.ssnVal
            };
        }
        console.log('#### createNewMCI clientJSON: ' + JSON.stringify(clientJSON));

        insertNewClient({client: JSON.stringify(clientJSON)})
        .then((result) => {
            console.log('#### createNewMCI result: ' + result);
            var response = result.split('####');
            console.log('#### response: ' + JSON.stringify(response));
            if (response[0] == '200')
            {
                this.updateMciID(response[1].replace(/"/g, ''));
            }
            /* else if (response[0] == '500')
            {} */
            else
            {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: 'MCI is currently unavailable. Please contact the DHS Service Desk at (412) 350-4357 or ServiceDesk@AlleghenyCounty.US. The error code is: {0}',
                        messageData : [response[0]],
                        variant: 'error',
                        mode: 'sticky'
                    })
                );
            }
        })
        .catch((error) => {
            this.error = error;
            console.log('#### createNewMCI error: ' + JSON.stringify(error));
        });
    }

    updateDataBackToMCI (mciId)
    {
        var clientJSON;
        if (this.ssnVal == null || this.ssnVal == '' || this.ssnVal == undefined)
        {
            var clientJSON = {
                "sourceSystemId" : "53",
                "sourceSystemClientId" : this.clientIdVal,
                "firstName" : this.fNameVal,
                "lastName" : this.lNameVal,
                "genderCode" : this.legalSexVal,
                "birthDate" : this.dobVal,
                "mciId" : mciId
            };
        }
        else
        {
            var clientJSON = {
                "sourceSystemId" : "53",
                "sourceSystemClientId" : this.clientIdVal,
                "firstName" : this.fNameVal,
                "lastName" : this.lNameVal,
                "genderCode" : this.legalSexVal,
                "birthDate" : this.dobVal,
                "ssn" : this.ssnVal,
                "mciId" : mciId
            };
        }
        console.log('#### updateDataBackToMCI clientJSON: ' + JSON.stringify(clientJSON));

        updateClient({client: JSON.stringify(clientJSON)})
        .then((result) => {
            console.log('#### updateDataBackToMCI result: ' + result);
            var response = result.split('####');
            console.log('#### response: ' + JSON.stringify(response));
            if (response[0] == '200')
            {
                //this.updateMciID(response[1].replace(/"/g, ''));
            }
            /* else if (response[0] == '500')
            {} */
            else
            {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: 'MCI is currently unavailable. Please contact the DHS Service Desk at (412) 350-4357 or ServiceDesk@AlleghenyCounty.US. The error code is: {0}',
                        messageData : [response[0]],
                        variant: 'error',
                        mode: 'sticky'
                    })
                );
            }
        })
        .catch((error) => {
            this.error = error;
            console.log('#### updateDataBackToMCI error: ' + JSON.stringify(error));
        });
    }
}