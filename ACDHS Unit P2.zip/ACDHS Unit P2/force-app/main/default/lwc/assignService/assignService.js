import { LightningElement, track, wire } from 'lwc';
import getMembers from '@salesforce/apex/AssignServiceController.getMembers';

const columns = [
    { label: 'Name', fieldName: 'clientName', fixedWidth: 200 },
    { label: 'MCI ID', fieldName: 'clientMCIId', fixedWidth: 150},
    { label: 'Relationship', fieldName: 'relationship', fixedWidth: 125},
    { label: 'DOB', fieldName: 'clientDOB', fixedWidth: 100},
    {
        type: "button",
        fixedWidth: 150,
        label:"Select",
        typeAttributes: {
            label:{fieldName: 'selectToggle'},
            title: 'Select',
            name: 'select',
            value: 'select',
            variant: {fieldName: 'selectButtonVariant'},
            disabled: {fieldName: 'isSelectDisabled'}
        }
    },
    {
        type: "button",
        fixedWidth: 150,
        label:"Get MCI ID",
        typeAttributes: {
            label: "Get MCI ID",
            title: 'getMciId',
            name: 'getMciId',
            value: 'getMciId',
            variant: 'brand',
            disabled: {fieldName: 'isGetMCIDisabled'}
        }
    },
];

export default class AssignService extends LightningElement {
    referralId = 'a0G3R000000ASV5UAO';
    @track membersList;
    error;
    columns = columns

    @wire(getMembers, {referralId : '$referralId'})
    wiredMembers({error, data}){
        if(data){
            this.membersList = JSON.parse(JSON.stringify(data));
            this.error = undefined;
            console.log('Members # '+JSON.stringify(this.membersList));
        }else if(error){
            this.membersList = undefined;
            this.error = error;
        }
    }

    handleRowAction(event){
        let actionName = event.detail.action.name;
        let selectedClientId = event.detail.row.clientId;
        console.log("Button name # "+event.detail.action.name);
        console.log("Row data # "+JSON.stringify(event.detail.row.clientId));
        if(actionName === 'select'){
            let selPos = this.membersList.findIndex(j=>j.clientId===selectedClientId);
            if(this.membersList[selPos].selectToggle === 'Select'){
                this.membersList[selPos].selectToggle = 'Selected';
                this.membersList[selPos].selectButtonVariant = 'success';
            }else{
                this.membersList[selPos].selectToggle = 'Select';
                this.membersList[selPos].selectButtonVariant = 'neutral';
            }
            console.log("Updated # "+JSON.stringify(this.membersList));
            this.membersList = JSON.parse(JSON.stringify(this.membersList));
        }
    }
}