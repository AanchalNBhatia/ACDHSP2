import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import userId from '@salesforce/user/Id';
import checkUserAccessOnReferral from '@salesforce/apex/DocCollectionCtrl.checkUserAccessOnReferral';
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';

export default class ServiceSelectionContainer extends NavigationMixin(LightningElement) {
    @api recordId;
    referralStatus;
    isSelectMembers = true;
    isSelectService = false;
    isReviewService = false;
    selectedMembers;
    selectedService;
    isAccepted = true;
    disableSubmit = false;
    loggedInUserID = userId;
    isAccess;
    accountId;
    isAdminAccess;
    isACDHS;
    isPortal;
    userTitle;
    userProfile;

    connectedCallback() {
        console.log("UID # ", this.loggedInUserID);
        checkUserAccessOnReferral({UserId: this.loggedInUserID, ReferralId: this.recordId})
        .then(result=>{
            let resultWrap = result;
            this.isAccess = resultWrap.isAccess;
            this.accountId = resultWrap.AccountId;
            this.isAdminAccess = resultWrap.isAdminAccess;
            if(this.accountId === '' || this.accountId === undefined || this.accountId == null){
                this.isACDHS = true;
                this.isPortal = false;
            }
            else{
                this.isACDHS = false;
                this.isPortal = true;
            }

            if(this.isAccess === false && !this.isAdminAccess){
                const toastEve = new ShowToastEvent({
                    mode: "dismissable",
                    variant: "error",
                    title: "No Access",
                    message: "You don't have access to Select services on this Referral"
                });
                this.dispatchEvent(toastEve);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
            if(!this.isAccess && this.isAdminAccess){
                this.isAccess = true;
            }
            console.log(this.isACDHS, this.isPortal, this.isAccess, this.isAdminAccess, this.accountId)
        })
        .catch(error=>{
            console.error(error);
        })

        getUserInfo({uId: this.loggedInUserID})
        .then(result=>{
            this.userTitle = result.userTitle;
            this.userProfile=result.userProfile;
            if(this.userProfile.includes('Read Only')){
                this.isReadOnly= true;
                const toastEve = new ShowToastEvent({
                    mode: "dismissable",
                    variant: "error",
                    title: "No Access",
                    message: "You don't have access to Select services on this Referral"
                });
                this.dispatchEvent(toastEve);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
        })
        .catch(error=>{
            console.error(error)
        })
    }

    get backDisabled(){
        return this.isSelectMembers || this.disableSubmit;
    }

    get nextDisabled(){
        if (this.selectedMembers && this.selectedMembers.length){
            if(this.isSelectMembers){
                if((this.selectedMembers.findIndex(j=>j.selectToggle==='Selected') !== -1)){
                    return false;
                }else{
                    return true;
                }
            }
        }else {
            return true;
        }
    }
    
    handleNav(event){
        let buttonName = event.target.title;
        if(buttonName === 'next'){
            if(this.isSelectMembers === true){
                this.isSelectMembers = false;
                this.isSelectService = true;
                this.isReviewService = false;
            }else if(this.isSelectService === true){
                if(this.selectedService){
                    this.isSelectMembers = false;
                    this.isSelectService = false;
                    this.isReviewService = true;
                }else{
                    alert("Please select a service");
                }
            }
        }else{
            if(this.isReviewService === true){
                this.isSelectMembers = false;
                this.isSelectService = true;
                this.isReviewService = false;
            }else if(this.isSelectService === true){
                this.isSelectMembers = true;
                this.isSelectService = false;
                this.isReviewService = false;
            }
        }
    }

    handleMembersSelection(event){
        this.selectedMembers = event.detail;
        if(this.selectedMembers.length){
            console.log("Selected members # "+JSON.stringify(this.selectedMembers));
        }
    }

    handleServiceSelection(event){
        this.selectedService = event.detail;
    }

    handleSubmit(event){
        this.template.querySelector('c-review-service-selection').handleSubmit();
    }

    handleRecordSave(event){
        this.disableSubmit = true;
        const successEvent = new CustomEvent('success'); 
        this.dispatchEvent(
        new ShowToastEvent({
            title: 'Record created.',
            message: "Client Service record has been created.",
            variant: 'success'
        }))
        this.dispatchEvent(successEvent);
        const recordCreatedEvent = new CustomEvent("recordscreated");
        this.dispatchEvent(recordCreatedEvent);
        this.navigateToRecordPage();
    }

    navigateToRecordPage() {
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: this.recordId,
                objectApiName: 'Referral__c',
                relationshipApiName: 'Client_Services__r',
                actionName: 'view'
            }
        });
    }
}