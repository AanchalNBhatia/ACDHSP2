import { LightningElement, wire, track } from 'lwc';
import allegheny_logo from '@salesforce/resourceUrl/Allegheny_Long_Logo';
import user_Id from '@salesforce/user/Id';
import getUserDetails from '@salesforce/apex/SPPortalContainerCntrl.getUserDetails';

export default class SpHeader extends LightningElement {
    logo = allegheny_logo;
    userId = user_Id;
    @track loggedInUser = [];
    accName; conTitle;
    profileName;

    @wire(getUserDetails, { userId: '$userId'})//0053S000000I371
    wiredUserDetails (result) {
        if (result.data)
        {
            this.loggedInUser = result.data;
            console.log('#### user123: ' + JSON.stringify(result.data));
            //console.log('#### user: ' + JSON.stringify(result.data.Contact));
            /* if (result.data.Contact != undefined && result.data.Contact != null) //Provider User
            {
                this.accName = result.data.Contact.Account.Name;
                this.conTitle = result.data.Contact.Title;
            }
            else //ACDHS User
            {
                this.accName = result.data.Account.Name;
                this.conTitle = result.data.Title;
            } */

            this.profileName = result.data.Profile.Name;
            if (this.profileName.includes('Provider')) //Provider User
            {
                this.accName = result.data.Contact.Account.Name;
                this.conTitle = result.data.Contact.Title;
            }
            else //ACDHS User
            {
                this.accName = 'ACDHS';
                this.conTitle = 'ACDHS Employee';
            }
        }
        else if (result.error)
        {
            this.error = result.error;
            console.log('#### error: ' + JSON.stringify(result.error));
        }
    }

    handleLogOut () {
        //window.location.replace("https://cmisdev1-provider1.cs133.force.com/providerPortal/secur/logout.jsp?retUrl=https%3A%2F%2Fcmisdev1-provider1.cs133.force.com%2FproviderPortal%2Fs%2Flogin%2F");
        window.location.replace("https://alleghenycounty-demo.oktapreview.com");
    }

    goToHome () {
        window.location.replace("https://cmisdev1-provider1.cs133.force.com/providerPortal/s/");
    }
}