import { LightningElement,wire,track,api} from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {getObjectInfo} from 'lightning/uiObjectInfoApi';
import ConcreteGoods_Obj from '@salesforce/schema/Concrete_Goods__c';
export default class RecordConcreteGoods extends LightningElement {

    @api isModalOpen=false;
    @api clientId;
    @api interactionId;
    @api clientName;
    @api recRtName;
    allRTInfo={};
    @track selectedRTId = '';
    conGoodsId;
    conGoodsFields=[];
    @api objRecordId;
    @wire(getObjectInfo,{objectApiName:ConcreteGoods_Obj})
    wiredObjectData(result){
        if(result.data){
            this.allRTInfo = result.data.recordTypeInfos;
            Object.entries(this.allRTInfo).forEach(item=>{
                if(item[1].name == this.recRtName){
                    console.log(item[1].name);
                    this.selectedRTId = item[1].recordTypeId;
                    console.log('In Record '+this.selectedRTId);
                }
            })
        }
    }
    openModal()
    {
        this.isModalOpen=true;
        console.log('In Record '+this.objRecordId);
    }
    closeModal()
    {
        this.isModalOpen=false;
        const closeevent2= new CustomEvent('closeevent2', {
            detail:{} 
        });
        this.dispatchEvent(closeevent2);
        //console.log(closeEvent)
    }
    handleClear()
    {
        this.template.querySelectorAll('lightning-input-field').forEach(each => {
            each.value = null;
        });
    }
    handleSave(event)
    {
        event.preventDefault(); 
        const fields = event.detail.fields;
        fields.Client__c=this.clientId;
        fields.Interaction__c=this.interactionId;
        if(this.recRtName==='Referral')
        {
            fields.Referral__c = this.objRecordId;
        }else{
            fields.Client_Service__c = this.objRecordId
        }
        
        fields.RecordTypeId=this.selectedRTId;
        this.conGoodsFields=fields;
        console.log(JSON.parse(JSON.stringify(this.conGoodsFields)));
        this.template.querySelector('lightning-record-edit-form').submit(fields);
        
    }
    handleSuccess(event)
    {
        this.conGoodsId=event.detail.Name;
        //console.log(this.conGoodsId);
        const toastEvent = new ShowToastEvent({
            title: 'Success !!',
            message: 'Concrete Goods saved for Client '+this.clientName,
            variant:'success'
        });
        this.dispatchEvent(toastEvent);
        this.isModalOpen = false;
        const closeEvent= new CustomEvent('closeevent', {
            detail:{} 
        });
        this.dispatchEvent(closeEvent);
    }
    handleError(event){
        //event.preventDefault();
        console.log('Inside handle error');
        console.log(event);
        console.log(JSON.parse(JSON.stringify(event.detail)));
    }
}