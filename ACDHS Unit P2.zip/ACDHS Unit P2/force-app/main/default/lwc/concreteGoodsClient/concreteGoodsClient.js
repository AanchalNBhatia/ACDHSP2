import { LightningElement,wire,track,api } from 'lwc';
import getClientData from '@salesforce/apex/ExternalReferralController.getClient';
import getConGoods from '@salesforce/apex/ExternalReferralController.getConGoods';
import getObjId from '@salesforce/apex/ExternalReferralController.getObjId';
import userId from '@salesforce/user/Id';
import portalURL from '@salesforce/label/c.Portal_URL';
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import Status_Field from '@salesforce/schema/Referral__c.Referral_Status__c';
import RecTypeID_Field from '@salesforce/schema/Encounter__c.RecordType.Name';
import {getRecord, getFieldValue} from 'lightning/uiRecordApi';
import {getObjectInfo} from 'lightning/uiObjectInfoApi';

export default class ConcreteGoodsClient extends LightningElement {

    @track showConGoods=false;
    @track isModalOpen=false;
    @api recordId;
    @api objectApiName;
    @track cliList=[];
    @track conGoodsList;
    recInfoName;
    @track interactionRTName;
    @track userProfile='';
    clientId='';
    clientName='';
    recinfos;
    @track objId='';
    @track refStat;
    masterList=[];
    uID=userId;
    pURL=portalURL;
    error;

    @track cliColumns = [{
        label: 'Client Id',fieldName: 'clientName',type: 'text',sortable: true
    },
    {
        label: 'Client Name',fieldName: 'clientFullName',type: 'text',sortable: true
    },
    {
        label: 'DOB',fieldName: 'clientDOB',type: 'date',sortable: true,
        typeAttributes: {
            day: "numeric",
            month: "numeric",
            year: "numeric"
        }
    },
    {
        label: 'Concrete Goods',type: 'button',
        typeAttributes: {
            label: 'Create',
            title: 'create',
            name: 'concretegoods',
            value: 'concretegoods',
            variant: 'brand',
            class: 'scaled-down',
        }
    },
 
    ];
    @track cgColumns = [{
        label: 'ID', fieldName: 'Id', type: 'url',sortable: true,
        typeAttributes:{
            label:{fieldName:'Name'},
            target:'_blank'
        }
    },
    {
        label: 'Client Name', fieldName: 'Client_Name__c', type: 'text', sortable: true
    },
    {
        label: 'Category',fieldName: 'Category__c',type: 'text',sortable: true
    },
    {
        label: 'Quantity',fieldName:'Number_of_Item_Provided__c', type: 'text'

    },
    {
        label: 'Description',fieldName:'Description_of_Items_Provided__c', type: 'text'

    },
    ];

    @wire(getClientData, {intId: '$recordId', rtName:'$interactionRTName'})
    wiredClients(result) {
        if (result.data) {
            this.refStat=result.data[0].refStatus;
            if(this.refStat =='Not Accepted' && this.refStat != null){
                const event = new ShowToastEvent({
                    title: 'Error',
                    message: 'Sorry, Concrete Goods can\'t be assigned with Referral status as \'Not Accepted\'',
                    variant: 'error'
                });
                this.dispatchEvent(event);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
            else{
                this.cliList = JSON.parse(JSON.stringify(result.data));
                this.objId=this.cliList[0].objId;
                console.log('#### ID: ' + this.objId);
            }
        } else if (result.error) {
            //console.log('Error '+JSON.stringify(error));
            this.error = result.error;
        }
    }
    @wire (getUserInfo, {uId: '$uID'})
        wiredUserInfo (result) {
        if (result.data)
        {
            //console.log('#### User Data: ' + JSON.stringify(result.data));
            this.userProfile=result.data.userProfile;
            //console.log('#### uProfile: ' + this.userProfile);
            if(this.userProfile.includes('Read Only')){
                this.isReadOnly= true;
            }
        }
        else if (result.error)
        {
            this.error = result.error;
            this.isError = true;
        }
    }
    @wire(getConGoods,{intId: '$recordId'})
        wiredExRef(result){
            this.masterList = result;
            if(result.data) {
                this.conGoodsList=JSON.parse(JSON.stringify(result.data));
                this.conGoodsList.forEach(congood =>{
                    if(this.userProfile==='Provider Users' ||this.userProfile==='Internal Portal Users')
                    {
                //console.log(this.pURL+"detail/"+interactionId);
                        congood.Id="/portal/s/detail/"+congood.Id;
                    }else{
                        congood.Id="/"+congood.Id;
                    }
                    
                })
            }else if (result.error) {
                //console.log('Error '+JSON.stringify(error));
                this.error = result.error;
            }
        }
    /*@wire(getObjId,{intId:'$recordId',rtName:'$interactionRTName'})
        wireRefID({
            error,
            data
        }) {
            if (data) {
                this.objId = data;
                //console.log('#### ID: ' + this.objId);
            } else if (error) {
                //console.log('Error '+JSON.stringify(error));
                this.error = error;
            }
        }*/
   /* @wire (getRecord,{
        recordId:'$referralId',
        fields:[Status_Field]
    })
        wiredReferralResult(result){
            if(result.data){
                this.refStatus = getFieldValue(result.data, 'Referral__c.Referral_Status__c');
                //console.log(this.refStatus);
                if(this.refStatus =='Not Accepted'){
                    this.isNotAccepted = true;
                    const event = new ShowToastEvent({
                        title: 'Error',
                        message: 'Sorry, Concrete Goods can\'t be assigned with Referral status as \'Not Accepted\'',
                        variant: 'error'
                    });
                    this.dispatchEvent(event);
                    const closeLwc = new CustomEvent('close');
                    this.dispatchEvent(closeLwc);
                }
            }
            else if(result.error){
                console.log(result.error)
            }
        }*/
     @wire (getRecord,{
        recordId:'$recordId',
        fields:[RecTypeID_Field]
    })
       wiredInteractionRT(result){
            if(result.data){
                this.interactionRTName = getFieldValue(result.data, 'Encounter__c.RecordType.Name');
                //console.log('ingetRecord '+this.interactionRTName);
            }
            else if(result.error){
                console.log(result.error)
            }
        }
    /*@wire (getObjectInfo,{objectApiName:'Encounter__c'})
        wiredRecordTypeName({data,error}){
            if(data)
            {
                console.log('recid '+this.recInfoId);
                let recTypeID=this.recInfoId;
                this.recInfos=data.recordTypeInfos;
                console.log('recordinfo '+JSON.stringify(this.recInfos));
                Object.entries(this.recInfos).forEach(recinfo => {
                    if(recinfo[1].recordTypeId===recTypeID)
                    {
                        this.recInfoName=recinfo[1].name;
                        console.log('recname '+this.recInfoName);
                    }
                })
            }
            else if(error){
                this.error=error;
            }
        }*/
    
    openConcreteGoods(event)
    {
        var actionName=event.detail.action.name;
        console.log(event.detail.action.name);
        if(actionName === 'concretegoods')
        {
            this.showConGoods=true;
            this.clientId = event.detail.row.Id;
            this.clientName = event.detail.row.clientFullName;
        }
    }
    setShowConcreteGoods(event){
        this.showConGoods = false;
        refreshApex(this.masterList);
    }
    setCloseConGoods()
    {
        this.showConGoods = false;
    }
    handleClose(event)
    {
        const closeLwc = new CustomEvent('close');
        // Dispatches the event.
        this.dispatchEvent(closeLwc);
    }
}