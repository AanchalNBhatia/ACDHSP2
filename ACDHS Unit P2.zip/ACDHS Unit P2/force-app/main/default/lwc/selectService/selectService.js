import { LightningElement, track, wire, api } from 'lwc';
import getAvailableServices from '@salesforce/apex/AssignServiceController.getAvailableServices';
const columns = [
    { 
        label: 'Service Name', 
        fieldName: 'serviceURL',
        type: 'url',
        typeAttributes: {label: { fieldName: 'serviceName' }, 
        target: '_blank'},
        sortable: true
    },
    { label: 'Provider/Facilty', fieldName: 'providerName'},
    { label: 'Provider Type', fieldName: 'providerType'}
]

export default class SelectService extends LightningElement {
    @api referralId;
    @api existingSelection;
    @track selectedService =[];
    @track services;
    unfilteredData;
    error;
    columns = columns;

    @wire(getAvailableServices, {referralId : '$referralId'})
    wiredServices({error, data}){
        if(data){
            this.services = JSON.parse(JSON.stringify(data));
            this.services.forEach(service => {
                service.serviceURL = '/'+service.SPServiceId;
            });
            console.log("Existing Selection outside # "+JSON.stringify(this.existingSelection));
            if(this.existingSelection && this.existingSelection.SPServiceId){
                console.log("Existing Selection # "+JSON.stringify(this.existingSelection));
                this.selectedService.push(this.existingSelection.SPServiceId);
                this.selectedService = JSON.parse(JSON.stringify(this.selectedService));
                this.services = JSON.parse(JSON.stringify(this.services));
            }
            this.unfilteredData = this.services;
            this.error = undefined;
        }else if(error){
            this.error = error;
            this.services = undefined;
        }
    }

    get isLoading(){
        return !this.services;
    }

    handleSearch(event){
        var searchTerm = event.target.value;
        this.services = this.unfilteredData.filter(function (obj) {
            return obj.serviceName.toLowerCase().includes(searchTerm.toLowerCase());
        });
        this.services = JSON.parse(JSON.stringify(this.services));
    }

    handleRowSelection(event){
        console.log("Row ",JSON.stringify(event.detail.selectedRows));
        let selectedRow = event.detail.selectedRows;

        const serviceSelectionEvent = new CustomEvent("serviceselection", {detail : selectedRow[0]});
        this.dispatchEvent(serviceSelectionEvent);
    }


}