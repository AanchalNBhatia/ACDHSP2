import { LightningElement, wire, track, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'
import getDocuments from '@salesforce/apex/DocCollectionCtrl.getAllDocs';
import updateDocumentName from '@salesforce/apex/DocCollectionCtrl.updateDocName';
import uploadToConAcc from '@salesforce/apex/DocCollectionCtrl.uploadToConAcc';
import updateCDL from '@salesforce/apex/DocCollectionCtrl.updateCDL';
import { refreshApex } from '@salesforce/apex';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import ContentVersion_Object from '@salesforce/schema/ContentVersion';
import Category_Field from '@salesforce/schema/ContentVersion.Document_Category__c';
import checkUserAccessOnReferral from '@salesforce/apex/DocCollectionCtrl.checkUserAccessOnReferral';
import checkUserAccessOnClientService from '@salesforce/apex/DocCollectionCtrl.checkUserAccessOnClientService';
import getRefDetails from '@salesforce/apex/DocCollectionCtrl.getRefDetails';
import getHelpText from '@salesforce/apex/DocCollectionCtrl.getHelpText';
import USER_ID from '@salesforce/user/Id'; 
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';
import { getRecord } from 'lightning/uiRecordApi';
export default class DocCollection extends LightningElement {
    @api recordId;
    @api objectApiName;
    @track docTypes = [];
    fileUploadDisabled = true;
    uploadToClient = false;
    uploadToHHAcc = false;
    clientId = [];
    priHHId =[];
    hideSharingCB = false;
    showClientShare = false;
    showHHShare = false;
    disableClientCB= false;
    disableAccHHCB= false;
    notes='';
    loggedInUserID = USER_ID;
    refOwnerId='';
    refOwnAccId ='';
    ownerCon = '';
    isOwnerACDHS = false;
    isOwnerPartner = false;
    showInp = false;
    accId='';
    con='';
    helpTextValue=''
    isAccess = true;
    isSite;
    isAdminAccess = false;
    isReadOnly = false;
    userProfile='';
    userTitle='';
    CSFields = [];
    connectedCallback(){
        console.log(this.objectApiName);
        getUserInfo({uId: this.loggedInUserID})
        .then(result=>{
            this.userTitle = result.userTitle;
            this.userProfile=result.userProfile;
            if(this.userProfile.includes('Read Only')){
                this.isReadOnly= true;
            }
        })
        .catch(error=>{
            console.error(error)
        })

        if(this.objectApiName == 'Referral__c'){
            this.showClientShare = true;
            this.showHHShare = true;
            console.log('Checking access on referral');
            checkUserAccessOnReferral({UserId: this.loggedInUserID, ReferralId: this.recordId})
            .then(result=>{
                let resultWrap = result;
                this.isAccess = resultWrap.isAccess;
                this.accountId = resultWrap.AccountId;
                this.isAdminAccess = resultWrap.isAdminAccess;
                if(this.accountId == '' || this.accountId == undefined || this.accountId == null){
                    this.isACDHS = true;
                    this.isPortal = false;
                }
                else{
                    this.isACDHS = false;
                    this.isPortal = true;
                }

                if(this.isAccess == false && !this.isAdminAccess){
                    const toastEve = new ShowToastEvent({
                        mode: "dismissable",
                        variant: "error",
                        title: "No Access",
                        message: "You don't have access to Upload/View Documents on this Referral"
                    });
                    this.dispatchEvent(toastEve);
                    const closeLwc = new CustomEvent('close');
                    this.dispatchEvent(closeLwc);
                }
                if(!this.isAccess && this.isAdminAccess){
                    this.isAccess = true;
                }
                console.log(this.isACDHS, this.isPortal,this.isAccess, this.isAdminAccess,this.accountId)
            })
            .catch(error=>{
                console.error(error);
            })
            console.log('getting clients and household Ids for referral');
            getRefDetails({referralId:this.recordId})
            .then(result=>{
                console.log(result);
                this.clientId= result.ClientIds;
                this.priHHId = result.HouseholdIds;
                this.hideSharingCB = result.isConfidential;
                if(this.clientId == null || this.clientId == undefined || this.clientId.length == 0){
                    this.disableClientCB = true;
                }
                if(this.priHHId == null || this.priHHId == undefined || this.priHHId.length == 0){
                    this.disableAccHHCB = true;
                }
            })
            .catch(error=>{
                console.error(error)
            })
        }
        else if(this.objectApiName == 'Client_Service__c'){
            console.log('Inside Client_Service__c');
            this.showClientShare = true;
            this.showHHShare = false;
            let FIELDS = [
                'Client_Service__c.Confidential_Referral__c',
                'Client_Service__c.Client__c',
            ];
            this.CSFields = FIELDS;

            checkUserAccessOnClientService({userId: this.loggedInUserID, csId: this.recordId})
            .then(result=>{
                let resultWrap = result;
                this.isAccess = resultWrap.isAccess;
                this.accountId = resultWrap.AccountId;
                this.isAdminAccess = resultWrap.isAdminAccess;
                
                if(this.isAccess == false && !this.isAdminAccess){
                    const toastEve = new ShowToastEvent({
                        mode: "dismissable",
                        variant: "error",
                        title: "No Access",
                        message: "You don't have access to Upload/View Documents on this Record"
                    });
                    this.dispatchEvent(toastEve);
                    const closeLwc = new CustomEvent('close');
                    this.dispatchEvent(closeLwc);
                }
                if(!this.isAccess && this.isAdminAccess){
                    this.isAccess = true;
                }
                console.log(this.isAccess, this.isAdminAccess,this.accountId)
            })
            .catch(error=>{
                console.error(error);
            })
        }
    }
    @wire(getRecord, { recordId: '$recordId', fields: '$CSFields' })
    wiredClientService({data, error}) {
        if(data) {
            let clientServiceRecord = data;
            console.log(clientServiceRecord)
            this.clientId= clientServiceRecord.fields.Client__c.value;
            console.log(this.clientId)
            this.hideSharingCB = clientServiceRecord.fields.Confidential_Referral__c.value;
            console.log(this.hideSharingCB);
        }
    }   
    //getting the picklist values of Document_Category__c
    @wire(getObjectInfo,{objectApiName: ContentVersion_Object})
    objectInfo;
    @wire(getPicklistValues, { recordTypeId: '$objectInfo.data.defaultRecordTypeId', fieldApiName: Category_Field})
    CategoryValues(result){
        if(result.data){
            this.docTypes = result.data.values;
        }
        if(result.error){
            console.log('_'+result.error);
        }
    };
    //columns to display in Lightning Datatable
    @track columns = [
        {label: 'Link', fieldName: 'urlId', type: 'url', fixedWidth: 80,
            	typeAttributes: {
                    label: 'Go to File',
                    target: '_blank'
                }
        },
        {label: 'Doc Type', fieldName: 'docType', type: 'text', wrapText: true},
        {label: 'File Name', fieldName: 'docTitle', type: 'text', editable: false, wrapText: true},
        {label: 'Notes', fieldName: 'docDesc', type: 'text', editable: true, wrapText: false},
        {label: 'Upload date', fieldName: 'uploadDate', type: 'date', editable: false},
        {label: 'Created By', fieldName: 'createdBy', type: 'text', editable: false},
    ];
    categoryHelpJSON = {
        
    }
    rowOffset = 0;
    @track listCDL = [];
    listAllDocs;
    selectedDocType;
    @track draftValues = [];

    get acceptedFormats () {
        return ['.pdf', '.txt', '.csv', '.doc', '.docx', '.xls', '.jpg', '.jpeg', '.png'];
    }

    //reading the data from salesforce to show in Lightning datatable
    @wire(getDocuments, {recId:'$recordId'})
    wiredJSONData (result) {
        this.listAllDocs = result;
        if (result.data)
        {
            this.listCDL = result.data;
        }
        else if (result.error)
        {
            this.error = result.error;
        }
    }
    @wire(getHelpText)
    wiredHelpTextJSON(result){
        if(result.data){
            this.categoryHelpJSON=result.data;
        }
        else if(result.error){

        }
    }
    handleChange (event) {
        if (event.target.name == 'docType')
        {
            this.fileUploadDisabled = false;
            this.selectedDocType = event.target.value;
            if(this.categoryHelpJSON[this.selectedDocType] != null || this.categoryHelpJSON[this.selectedDocType] != '' || this.categoryHelpJSON[this.selectedDocType] != undefined){
                this.helpTextValue = this.categoryHelpJSON[this.selectedDocType];
            }
            else{
                this.helpTextValue = '';
            }
        }
    }

    handleUploadFinished (event) {
        // Get the list of uploaded files
        const uploadedFiles = event.detail.files;
        //alert("No. of files uploaded : " + uploadedFiles.length);
        const toastEve = new ShowToastEvent({
            mode: "dismissable",
            variant: "success",
            title: "Document Saved!",
            message: "You can upload a new document."
        });
        this.dispatchEvent(toastEve);

        var fileId = uploadedFiles[0].documentId;

        updateDocumentName({docId: fileId, docName: this.selectedDocType, notes:this.notes})
        .then((result) => {
        })
        .catch((error) => {
        });

        //if upload to client or account
        if(this.uploadToClient || this.uploadToHHAcc){
            uploadToConAcc({DocId: fileId, ContactIds: this.clientId, AccountIds: this.priHHId, isContactUpload: this.uploadToClient, isAccountUpload: this.uploadToHHAcc})
            .then((result)=>{
                
            })
            .catch((error)=>{
                console.log(error)
            })
        }
        this.template.querySelectorAll('lightning-textarea').forEach(each => {
            each.value = null;
        });
        this.template.querySelectorAll('lightning-combobox').forEach(each => {
            each.value = null;
        });
        this.template.querySelectorAll('lightning-input').forEach(each=>{
            each.checked = false;
        })
        this.helpTextValue = '';
        this.notes = '';
        return refreshApex(this.listAllDocs);
    }

    handleSave (event) {
        this.draftValues = event.detail.draftValues;

        updateCDL({listCDL: this.draftValues, recId: this.recordId, str: JSON.stringify(this.draftValues)})
        .then((result) => {
            this.draftValues = [];
            return refreshApex(this.listAllDocs);
        })
        .catch((error) => {
        });
    }

    handleClientCBChange(event){
        this.uploadToClient = event.detail.checked;
    }
    handleHHAccCBChanged(event){
        this.uploadToHHAcc = event.detail.checked;
    }
    handleInpChange(event){
        if(event.target.name ==='notesInp'){
            this.notes = event.target.value;
        }
    }
}

/*@wire (getUserInfo, { uId: '$loggedInUserID'})
    wiredUserInfo (result) {
        if (result.data)
        {
            console.log('getUserInfo')
            this.userTitle = result.data.userTitle;
            this.userProfile=result.data.userProfile;
            console.log(this.userProfile);
            if(this.userProfile.includes('Read Only')){
                this.isReadOnly= true;
            }
        }
        else if (result.error)
        {
            this.error = result.error;
            
        }
    }*/
    /*@wire(checkUserAccessOnReferral,{UserId: '$loggedInUserID', ReferralId: '$recordId'})
    wiredAccessibilityResult(result){
        if(result.data){
            console.log(result.data)
            let resultWrap = result.data;
            this.isAccess = resultWrap.isAccess;
            this.accountId = resultWrap.AccountId;
            this.isAdminAccess = resultWrap.isAdminAccess;
            if(this.accountId == '' || this.accountId == undefined || this.accountId == null){
                this.isACDHS = true;
                this.isPortal = false;
            }
            else{
                this.isACDHS = false;
                this.isPortal = true;
            }

            if(this.isAccess == false && !this.isAdminAccess){
                const toastEve = new ShowToastEvent({
                    mode: "dismissable",
                    variant: "error",
                    title: "No Access",
                    message: "You don't have access to Upload/View Documents on this Referral"
                });
                this.dispatchEvent(toastEve);
                const closeLwc = new CustomEvent('close');
                this.dispatchEvent(closeLwc);
            }
        }
        else if(result.error){
            console.log(result.error)
        }
    }*/

    /*@wire(getRefDetails,{referralId: '$recordId'})
    wiredReferralResult(result){
        if(result.data){
            console.log(result.data);
            this.clientId= result.data.ClientIds;
            console.log('this.clientId....'+this.clientId)
            this.priHHId = result.data.HouseholdIds;
            console.log('this.priHHId....'+this.priHHId);
            this.hideSharingCB = result.data.isConfidential;
            if(this.clientId == null || this.clientId == undefined || this.clientId.length == 0){
                this.disableClientCB = true;
            }
            if(this.priHHId == null || this.priHHId == undefined || this.priHHId.length == 0){
                this.disableAccHHCB = true;
            }
        }
        if(result.error){
            console.log(error)
        }
    }*/