import { LightningElement, api, wire, track } from 'lwc';
import { createRecord, getRecord, getFieldValue } from 'lightning/uiRecordApi';
import Gender_Field from '@salesforce/schema/Client__c.Legal_Sex__c';
import FirstName_Field from '@salesforce/schema/Client__c.First_Name__c';
import LastName_Field from '@salesforce/schema/Client__c.Last_Name__c';
import MCI_Field from '@salesforce/schema/Client__c.Client_Create_MCI__c';
import getRelRuleWrapper from '@salesforce/apex/HouseHoldMngmtController.getRelRuleWrapper';
import getHHAcc from '@salesforce/apex/HouseHoldMngmtController.getHHAcc';
import Portal_URL from '@salesforce/label/c.Portal_URL';
import userId from '@salesforce/user/Id';
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';
import getExistingHouseholds from '@salesforce/apex/HouseHoldMngmtController.getExistingHouseholds';
import {refreshApex} from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class HouseHoldMngmt extends LightningElement {
    accName = '';
    accDetWrapper = null;
    showLoadingSpinner = false;
    clientId = ''
    @track gender=''
    @track firstName =''
    categoryList = [];
    relationList = [];
    ruleMap=null;
    hideRelationInput = true;
    relation ='';
    isPrimary= false;
    listToSave = [];
    @api recordId = '';
    priAccId;
    tempId = 0;
    firstName = '';
    lastName = '';
    selectedClientIds=[];
    isExistingHHEmpty = false;
    exitsingPriWrapper = null;
    existingPriAccName ='';
    existingPriAccId ='';
    fullName='';
    label = {
        Portal_URL,
    };
    uID=userId;
    genderJSON = {
        '1': 'Male',
        '2': 'Female',
        '3': 'Both',
        '4': 'Unknown'
    }
    @track existingList = [];
    @track existingClients=[];
    showFullName=true;
    wiredExistingHH=[];

    showMCITable = false;

    @wire (getUserInfo, { uId: '$uID'})
    wiredUserInfo (result) {
        if (result.data)
        {
            this.userTitle = result.data.userTitle;
            this.userProfile=result.data.userProfile;
        }
        else if (result.error)
        {
            this.error = result.error;
            
        }
    }
    //selecting or creating a client from look up
    handleSecondaryMemChange(event){
        this.clientId = event.detail.value[0];
        this.showFullName = true;
        console.log('existingClients handleSecondaryMemChange....'+this.existingClients);
        if(this.existingClients != null && this.existingClients != undefined && this.existingClients.length>0){
            if(this.existingClients.includes(this.clientId)){
                console.log('client already exists');
                this.handleClear();
                const toastEvent = new ShowToastEvent({
                    title: 'Error !!',
                    message: 'This client is already a member of the Household.',
                    variant:'error'
                });
                this.dispatchEvent(toastEvent);
            }
        }
        if(this.clientId == this.recordId){
            this.handleClear();
            const toastEvent = new ShowToastEvent({
                title: 'Error !!',
                message: 'This client is already a member of the Household.',
                variant:'error'
            });
            this.dispatchEvent(toastEvent);
        }
        this.template.querySelectorAll('lightning-input').forEach(each=>{
            each.checked = false;
        })
        getHHAcc({clientId: this.clientId, isDepMember: true})                            
        .then(result=>{
            this.exitsingPriWrapper = result;
            //console.log(result);
            this.existingPriAccName = this.exitsingPriWrapper.accountName;
            this.existingPriAccId = this.exitsingPriWrapper.accountId;
        })
        .catch(error =>{
            console.log(error)
        })
    }
    //getting the existing record from sf
    @wire(getExistingHouseholds, { clientId: '$recordId', accId: '$priAccId' })
    wiredWrapperData(result) {
        this.wiredExistingHH = result;
        if (result.data) {
            this.existingList =result.data;
            console.log(this.existingList);
            for(var member in this.existingList){
                this.existingClients.push(this.existingList[member].priConId);
            }
            console.log('getExistingHouseholds....'+this.existingClients);        
        }
        else if (result.error) {
            this.error = result.error;
            this.isExistingHHEmpty = true;
        }
    }
    //getting the selected clients details
    //getting the gender for selected contact, gender is needed for relation values
    @wire(getRecord,{
        recordId: '$clientId',
        fields: [Gender_Field, FirstName_Field, LastName_Field, MCI_Field],
    })
    wiredContactResult(result){
        if(result.data){
            this.gender = getFieldValue(result.data, 'Client__c.Legal_Sex__c');
            this.gender = this.genderJSON[this.gender];
            this.firstName = getFieldValue(result.data, 'Client__c.First_Name__c');
            this.lastName = getFieldValue(result.data, 'Client__c.Last_Name__c');
            this.fullName = this.firstName + ' '+this.lastName;
            if (getFieldValue(result.data, 'Client__c.Client_Create_MCI__c') == false)
            {
                this.showMCITable = true;
            }
        }
        else if(result.error){
            console.log('Error....'+JSON.stringify(result.error))
        }
    }
    //read the category and relation rules from MDT (using apex)
    connectedCallback() {
        this.showLoadingSpinner = true;
        //console.log(this.recordId);
        getRelRuleWrapper()
        .then(result =>{
            this.resultWrapper = result;
            if(result.uniqueCategories != null && result.uniqueCategories != undefined && result.uniqueCategories.length >0 ){
                result.uniqueCategories.forEach(item=>{
                    this.categoryList=[...this.categoryList, {value:item, label:item}]
                })
            }
            if(result.genCatToTypeValues != null && result.genCatToTypeValues != undefined){
                this.ruleMap = result.genCatToTypeValues;
            }
            //console.log(this.ruleMap);
        })
        .catch(error=>{
            console.log(error)
        })

        getHHAcc({clientId: this.recordId})
        .then(result=>{
            this.accDetWrapper = result;
            this.accName = this.accDetWrapper.accountName;
            this.priAccId = this.accDetWrapper.accountId;
        })
        .catch(error =>{
            console.log(error)
        })
        this.showLoadingSpinner = false;
    }
    //event fired on the change of category 
    //this checks the gender n category and populates the relationList for combo box
    selectRelList(event){
        var inpName = event.target.name;
        if(inpName === "categoryInput"){
            this.categoryValue = event.detail.value;
        }
        else if(inpName ==="relNameInput"){
            this.relation = event.detail.value;
        }
        if(this.gender != '' && this.categoryValue != '' ){
            
            this.relationList=[];
            this.hideRelationInput = false;
            let mapKey = this.gender + '_' + this.categoryValue;
            
            let mapValues = this.ruleMap[mapKey];
            
            let tempList = mapValues.split('#')
            
            tempList.forEach(item =>{
                this.relationList = [...this.relationList, {value: item, label: item}]
            })
            
        }
    }
    //function executed when checkbox is checked
    handleCBChange(event){
        this.isPrimary = event.detail.checked;
             
        if(this.isPrimary){
            if(this.exitsingPriWrapper != null && (this.existingPriAccName != undefined && this.existingPriAccName != null && this.existingPriAccName !='') && (this.existingPriAccId != this.priAccId)){
                const toastEvent = new ShowToastEvent({
                    title: 'Error !!',
                    message: 'The client already has '+ this.existingPriAccName + ' as Primary household, There cant be two primary houeholds',
                    variant:'error'
                });
                this.dispatchEvent(toastEvent);
                //alert('The client already has '+ this.existingPriAccName + ' as Primary household, There cant be two primary houeholds');
                this.isPrimary = false;
                this.template.querySelectorAll('lightning-input').forEach(each=>{
                    each.checked = false;
                })
            }
        }
        else{

        }
    }
    
    handleSave(event){
        event.preventDefault(); 
        if(this.clientId=='' || this.categoryValue =='' || this.relation ==''){
            alert('Please fill all the required field')
        }
        else{
            var fields = {
                'Secondary_Member__c': this.recordId,
                'Primary_Member__c': this.clientId,
                'Type__c': this.categoryValue,
                'Relation__c': this.relation
            }
            var objRecordInput = {'apiName':'Relationship__c', fields}
            createRecord(objRecordInput).then(response=>{
                var fields = {
                    'Client__c': this.clientId,
                    'Account__c': this.priAccId ,
                    'Primary__c': this.isPrimary
                }
                var objRecordInput = {'apiName': 'Account_Client__c', fields}
                createRecord(objRecordInput).then(response=>{
                    this.showLoadingSpinner=false;
                    this.existingClients.push(this.clientId);
                    console.log('handleSave....'+this.existingClients);
                    refreshApex(this.wiredExistingHH)
                }).catch(error => {
                    console.log(error)
                    console.log('Error: ' +JSON.stringify(error));
                });
            }).catch(error => {
                console.log('Error: ' +JSON.stringify(error));
            });
            
            this.template.querySelectorAll('lightning-input-field').forEach(each => {
                each.value = null;
            });
            this.template.querySelectorAll('lightning-combobox').forEach(each => {
                each.value = null;
            });
            this.template.querySelectorAll('lightning-input').forEach(each=>{
                each.checked = false;
            })
            var navURL = '';
            if(this.userProfile == 'System Administrator' || this.userProfile == 'Internal Super User'){
                navURL ='/' + this.clientId;
            }
            else{
                navURL = Portal_URL+'/client/'+ this.clientId;
            }
            var newItem = {
                name: this.firstName+' ' +this.lastName,
                category:this.categoryValue,
                gender:this.gender,
                relation:this.relation,
                isSaved: false,
                relId: this.tempId + 1,
                isDirect: this.isPrimary,
                url: navURL,
                priConId: this.clientId
            }
            this.isExistingHHEmpty = false;
            //send newly created record to the parent
            const selectedEvent = new CustomEvent("newmemadded", {
                detail: newItem
            });
            // Dispatches the event.
            this.dispatchEvent(selectedEvent);
        }
    }
    //on click of cancel
    handleClear(){
        this.showFullName = false;
        this.template.querySelectorAll('lightning-input-field').forEach(each => {
            each.value = '';
            each.reset();
        });
        this.template.querySelectorAll('lightning-combobox').forEach(each => {
            each.value = null;
        });
        this.template.querySelectorAll('lightning-input').forEach(each=>{
            each.checked = false;
        })
    }

    closeMCITable () {
        this.showMCITable = false;
    }
    //this method saves the data from listToSave to sf
    /*@api doSave(){
        if(this.listToSave != null && this.listToSave != undefined && this.listToSave.length >0){
            this.showLoadingSpinner=true;
            this.listToSave.forEach(record =>{
                if(record.relRec != null && record.relRec != undefined){
                    var relDetails = record.relRec;
                    var fields = {
                        'Secondary_Member__c': relDetails.Secondary_Member__c,
                        'Primary_Member__c': relDetails.Primary_Member__c,
                        'Type__c': relDetails.Type__c,
                        'Relation__c': relDetails.Relation__c
                    }
                    var objRecordInput = {'apiName':'Relationship__c', fields}
                    createRecord(objRecordInput).then(response=>{
                        if(record.juncRec != null && record.juncRec != undefined){
                            var juncDetails = record.juncRec;
                            var fields = {
                                'Client__c': juncDetails.Client__c,
                                'Account__c': juncDetails.Account__c,
                                'Primary__c': juncDetails.Primary__c
                            }
                            var objRecordInput = {'apiName': 'Account_Client__c', fields}
                            createRecord(objRecordInput).then(response=>{
                                this.showLoadingSpinner=false;
                                this.existingClients.push(relDetails.Primary_Member__c);
                                console.log('doSave....'+this.existingClients);
                            }).catch(error => {
                                console.log('Error: ' +JSON.stringify(error));
                            });
                        }
                    }).catch(error => {
                        console.log('Error: ' +JSON.stringify(error));
                    });
                }
            })
        }
        else{
            console.log('list to save is blank')
        }
    }*/
}