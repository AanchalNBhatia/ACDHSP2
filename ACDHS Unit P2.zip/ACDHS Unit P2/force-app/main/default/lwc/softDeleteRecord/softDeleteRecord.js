import { LightningElement,api, track,wire } from 'lwc';
import { updateRecord } from "lightning/uiRecordApi";
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import ownerName from '@salesforce/label/c.Delete_Record_Owner';
import pURL from '@salesforce/label/c.Portal_URL';
import { getObjectInfo, getRecord } from 'lightning/uiObjectInfoApi';
import userId from '@salesforce/user/Id';
import Name_Field from '@salesforce/schema/User.Name';
import validUser from '@salesforce/apex/userDetails.validUser';
import checkAccess from '@salesforce/apex/userDetails.checkAccess';
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';
import deleteClient from '@salesforce/apex/softDeleteRecordController.deleteClientRecords';
import deleteReferral from '@salesforce/apex/softDeleteRecordController.deleteReferralRecords';
import deleteInteraction from '@salesforce/apex/softDeleteRecordController.deleteInteractionRecords';
import deleteAccount from '@salesforce/apex/softDeleteRecordController.deleteAccountRecords';
import { refreshApex } from '@salesforce/apex';

export default class SoftDeleteRecord extends LightningElement {
@api recordId;
@api objectApiName;
@track isModalOpen = false;
OwnId=ownerName;
uID=userId;
isValid=false;
isDelete=false;
@track porURL=pURL;
currentURL=window.location.href;
//currentUserTitle=TITLE_FIELD;
@track userTitle='';
hasAccess=false;
infix='';
@track userProfile='';
isError = false;
@wire (getUserInfo, { uId: '$uID'})
    wiredUserInfo (result) {
        if (result.data)
        {
            //console.log('#### User Data: ' + JSON.stringify(result.data));
            this.userTitle = result.data.userTitle;
            this.userProfile=result.data.userProfile;
            console.log('#### uTitle: ' + this.userTitle);
            console.log('#### uProfile: ' + this.userProfile);
            //console.log('####URL: ' + window.location.href);
            //console.log('####PURL: ' + this.porURL);
            //console.log('####PURL: ' + this.porURL.length);
        }
        else if (result.error)
        {
            this.error = result.error;
            this.isError = true;
        }
    }

@wire (validUser)
wiredUserValid(result) {
    if (result.data != undefined) 
    {
        this.isValid=result.data;
        //console.log('#### Valid: ' + this.isValid);   
    }
    else if (result.error)
    {
        this.error = result.error;
        this.isError = true;
    }
}
@wire(checkAccess, { recId: '$recordId'})
    wiredUserDetails (result) {
        //console.log('#### ref access: ' + result.data);
        if (result.data != undefined)
        {
            //console.log('#### ref access: ' + JSON.stringify(result.data));
            this.hasAccess = result.data;
            console.log('#### access: ' + this.hasAccess);
        }
        else if (result.error)
        {
            this.error = result.error;
            //console.log('#### error: ' + JSON.stringify(result.error));
            this.isError = true;
        }
    }
async handleClick()
{
    const closeDR = new CustomEvent('close'); 
    
    if ((this.userTitle==='Super User' || this.userTitle==='Sys Admin')|| this.userProfile==='System Administrator')
    {
        if (this.hasAccess===true)
        {
            if(this.isValid===true)
            {
                switch(this.objectApiName){
                    case 'Referral__c':
                        await deleteReferral({refId : this.recordId})
                        .then(result =>{
                            console.log('Result'+result);
                        })
                        .catch(error=>{
                            this.isError = true;
                            //console.log('Referral....');
                            console.log(error);
                        })  
                        this.infix = 'referral';  
                    break;
                    case 'Client__c':
                        await deleteClient({clientId : this.recordId})
                        .then(result =>{
                            
                            })
                        .catch(error=>{
                            console.log('Client....');
                            this.isError = true;
                            console.log(error);
                        })  
                        this.infix = 'client';
                    break;
                    case 'Encounter__c':
                        await deleteInteraction({intIDList : this.recordId})
                        .then(result =>{
                            
                            })
                        .catch(error=>{
                            console.log('Encounter....');
                            this.isError = true;
                            console.log(error);
                        })  
                        this.infix = 'interaction';
                    break;
                    case 'Account':
                        await deleteAccount({accID : this.recordId})
                        .then(result =>{
                            
                            })
                        .catch(error=>{
                            this.isError = true;
                            console.log(error);
                        })
                        this.infix = 'account';
                    break;
                    
                    default:
                    break; 
                } 
                
                if(this.isError){
                    console.log(this.isError)
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error deleting record',
                            message: "Error deleting record..... Please contact System Administrator",
                            variant: 'error'
                        }))
                        this.dispatchEvent(closeDR);
                }
                else{
                    console.log(this.isError)
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Record Deleted',
                            message: "Record deleted successfully.",
                            variant: 'Success'
                        })
                    );
                    this.dispatchEvent(closeDR);
                    var urlLen=this.porURL.length;
                    var newUrl=this.currentURL.substring(0,urlLen);
                    console.log("URL "+newUrl);
                    if (this.porURL===newUrl)
                    {
                        switch(this.infix)
                        {
                            case 'interaction':
                                window.location.replace(this.porURL+"/referral/Referral__c/Default");
                                break;
                            case 'account':
                                window.location.replace(this.porURL+"/households");
                                break;
                            default:
                                window.location.replace(this.porURL+"/"+this.infix+"/"+this.objectApiName+"/Default");
                                break; 
                        }
                    }else
                    {
                        let url = "/lightning/o/"+this.objectApiName+"/list";
                        //console.log("@url: "+url);
                        window.location.replace(url);
                        
                    }
                }     
            }
            else{
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error deleting record',
                        message: "Deleted Record Owner is Blank, Inactive or Not Valid ID. Please contact System Administrator",
                        variant: 'error'
                    })
                    
                );
                this.dispatchEvent(closeDR);
            }
        }
        else{
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error deleting record',
                    message: "You do not have Access to Delete the Record. Please contact System Administrator",
                    variant: 'error'
                })
            );
            this.dispatchEvent(closeDR);
        }
    }else{
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error deleting record',
                message: "Only Super User and System Administrator can delete the record.",
                variant: 'error'
            })
        );
        this.dispatchEvent(closeDR);

    }
   
}
    handleClose()
    {
        const closeDR = new CustomEvent('close');
        this.dispatchEvent(closeDR);
        //console.log('#### objname: ' + this.objectApiName.Name);
    }
}