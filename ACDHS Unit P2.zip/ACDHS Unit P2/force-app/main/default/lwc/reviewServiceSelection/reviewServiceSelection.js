import { LightningElement, api, wire } from 'lwc';
import saveCSRecord from '@salesforce/apex/AssignServiceController.saveCSRecord';
import saveJunctionServiceRecords from '@salesforce/apex/AssignServiceController.saveJunctionServiceRecords';

const columns = [
    { label: 'Name', fieldName: 'clientName'},
    { label: 'MCI ID', fieldName: 'clientMCIId'},
    { label: 'Relationship', fieldName: 'relationship'},
    { label: 'DOB', fieldName: 'clientDOB'}
]

export default class ReviewServiceSelection extends LightningElement {
    @api recordId;
    @api selectedMembers;
    @api selectedService;
    selectedStartDate;
    columns = columns;
    disableStartDate = false;
    error;
    invalidStartDate = false;
    pastStartDate = false;
    isLoading = false;
    
    connectedCallback(){
        this.selectedStartDate = new Date().toISOString();
    }

    handleStartDateChange(event){
        console.log("changed date # ",event.target.value);
        let selDate = event.target.value;
        let inputFields = this.template.querySelectorAll('lightning-input');
        inputFields.forEach(input => {
            if(input.reportValidity() === false){
                this.invalidStartDate = true;
                this.pastStartDate = false;
            }else{
                var today = new Date();        
                var dd = today.getDate();
                var mm = today.getMonth() + 1;
                var yyyy = today.getFullYear();
                if(dd < 10){
                    dd = '0' + dd;
                } 
                if(mm < 10){
                    mm = '0' + mm;
                }
                
                var todayFormattedDate = yyyy+'-'+mm+'-'+dd;
                
                if(selDate != '' && selDate > todayFormattedDate){
                    this.pastStartDate = true;
                }else{
                    this.pastStartDate = false;
                    this.invalidStartDate = false;
                    this.selectedStartDate = selDate;
                }
            }
        });
    }

    @api
    handleSubmit(event){
        if(!this.invalidStartDate && !this.pastStartDate){
            this.isLoading = true;
            this.disableStartDate = true;
            //let csList = [];
            console.log("recordId # ",this.recordId);
            let cs = { 'sobjectType': 'Client_Service__c' };
            cs.Start_Date__c = this.selectedStartDate;
            cs.Referral__c = this.recordId;
            cs.SP_Service__c = this.selectedService.SPServiceId;
            if(cs){
                saveCSRecord({referralId : this.recordId, csRecord : cs})
                .then(result => {
                    let clientServiceRecId = result;
                    console.log('clientServiceRecId # ',clientServiceRecId);
                    let juncServiceList = [];
                    this.selectedMembers.forEach(member => {
                        let js = { 'sobjectType': 'Junction_Service__c' };
                        js.Client__c = member.clientId;
                        js.Client_Service__c = clientServiceRecId;
                        juncServiceList.push(js);
                    })
                    if(juncServiceList && juncServiceList.length){
                        saveJunctionServiceRecords({referralId : this.recordId, jsList : juncServiceList})
                        .then(result =>{
                            const recordSaveEvent = new CustomEvent("recordsave");
                            this.dispatchEvent(recordSaveEvent);
                            this.isLoading = false;
                        })
                        .catch(error => {
                            this.error = error;
                            console.log('Error # ',JSON.stringify(this.error));
                            this.disableStartDate = false;
                            this.isLoading = false;
                        })
                    }
                })
                .catch(error => {
                    console.log("Error ", JSON.stringify(error));
                })
            }
        }
    }
}