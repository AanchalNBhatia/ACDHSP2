import { LightningElement,wire,track,api } from 'lwc';
import getClientData from '@salesforce/apex/ExternalReferralController.getClient';
import getExReData from '@salesforce/apex/ExternalReferralController.getExRef';
import { refreshApex } from '@salesforce/apex';
import userId from '@salesforce/user/Id';
import portalURL from '@salesforce/label/c.Portal_URL';
import getUserInfo from '@salesforce/apex/userDetails.getUserInfo';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import RecTypeID_Field from '@salesforce/schema/Encounter__c.RecordType.Name';
import {getRecord, getFieldValue} from 'lightning/uiRecordApi';

export default class ExternalReferralClient extends LightningElement {
   
    @track columns = [{
        label: 'Client Id',fieldName: 'clientName',type: 'text',sortable: true
    },
    {
        label: 'Client Name',fieldName: 'clientFullName',type: 'text',sortable: true
    },
    {
        label: 'DOB',fieldName: 'clientDOB',type: 'date',sortable: true,
        typeAttributes: {
            day: "numeric",
            month: "numeric",
            year: "numeric"
        }
    },
    {
        label: 'External Referral',type: 'button',
        typeAttributes: {
            label: 'Create',
            title: 'create',
            name: 'referralOut',
            value: 'referralOut',
            variant: 'brand',
            class: 'scaled-down',
        }
    },
 
];
@track exColumns = [{
    label: 'ID', fieldName: 'Id', type: 'url',sortable: true,
    typeAttributes:{
        label:{fieldName:'Name'},
        target:'_blank'
    }
},
{
    label: 'Client Name', fieldName: 'Client_Name__c', type: 'text', sortable: true
},
{
    label: 'Category',fieldName: 'Referral_Category__c',type: 'text',sortable: true
},
{
    label: 'Referred To',fieldName:'Referred_To__c', type: 'text',

},
];
    @track openExReferral=false;
    @api isModalOpen=false;
    @api recordId;
    @track error;
    @track cliList;
    @track exrefList;
    @track userProfile='';
    @track interactionRTName;
    clientId='';
    clientName='';
    @track objId='';
    masterList=[];
    uID=userId;
    @track isReadOnly=false;
    pURL=portalURL;

    @wire (getRecord,{
        recordId:'$recordId',
        fields:[RecTypeID_Field]
    })
       wiredInteractionRT(result){
            if(result.data){
                this.interactionRTName = getFieldValue(result.data, 'Encounter__c.RecordType.Name');
                //console.log('ingetRecord '+this.interactionRTName);
            }
            else if(result.error){
                console.log(result.error)
            }
        }

    @wire(getClientData, {intId: '$recordId', rtName: '$interactionRTName'})
    wiredClients({
        error,
        data
    }) {
        if (data) {
            this.cliList = JSON.parse(JSON.stringify(data));
            this.objId=this.cliList[0].objId;
            console.log('#### ID: ' + this.objId);
        } else if (error) {
            //console.log('Error '+JSON.stringify(error));
            this.error = error;
        }
    }
    @wire (getUserInfo, {uId: '$uID'})
    wiredUserInfo (result) {
        if (result.data)
        {
            //console.log('#### User Data: ' + JSON.stringify(result.data));
            this.userProfile=result.data.userProfile;
            console.log('#### uProfile: ' + this.userProfile);
            if(this.userProfile.includes('Read Only')){
                this.isReadOnly= true;
            }
        }
        else if (result.error)
        {
            this.error = result.error;
            this.isError = true;
        }
    }
    @wire(getExReData,{intId: '$recordId'})
    wiredExRef(result){
        this.masterList = result;
        if(result.data) {
            this.exrefList=JSON.parse(JSON.stringify(result.data));
            this.exrefList.forEach(exref =>{
                if(this.userProfile==='Provider Users' ||this.userProfile==='Internal Portal Users')
        {
            //console.log(this.pURL+"detail/"+interactionId);
            exref.Id="/portal/s/detail/"+exref.Id;
        }else{
            exref.Id="/"+exref.Id;
        }
                
            })
        }else if (result.error) {
            //console.log('Error '+JSON.stringify(error));
            this.error = result.error;
        }
    }
   
    openExternalReferral(event)
    {
        
        var actionName=event.detail.action.name;
        //console.log(event.detail.action.name);
        if(actionName === 'referralOut')
        {
            this.openExReferral=true;
            this.clientId = event.detail.row.Id;
            this.clientName = event.detail.row.clientFullName;
        }
    }
    setShowExternalReferral(event){
        this.openExReferral = false;
        refreshApex(this.masterList);
    }
    setCloseExRef()
    {
        this.openExReferral = false;
    }
    handleClose(event)
    {
        const closeLwc = new CustomEvent('close');
        // Dispatches the event.
        this.dispatchEvent(closeLwc);
    }
}